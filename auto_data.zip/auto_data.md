```python
import pandas as pd
x=pd.read_csv("C:/Users/admin/Downloads/auto_data_1.csv",encoding='ISO-8859-1')
x
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>mpg</th>
      <th>cylinders</th>
      <th>displacement</th>
      <th>horsepower</th>
      <th>weight</th>
      <th>acceleration</th>
      <th>model_year</th>
      <th>origin</th>
      <th>name</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>18</td>
      <td>8</td>
      <td>307</td>
      <td>130</td>
      <td>3504</td>
      <td>12</td>
      <td>70</td>
      <td>1</td>
      <td>chevrolet chevelle malibu</td>
    </tr>
    <tr>
      <th>1</th>
      <td>15</td>
      <td>8</td>
      <td>350</td>
      <td>165</td>
      <td>3693</td>
      <td>12</td>
      <td>70</td>
      <td>1</td>
      <td>buick skylark 320</td>
    </tr>
    <tr>
      <th>2</th>
      <td>18</td>
      <td>8</td>
      <td>318</td>
      <td>150</td>
      <td>3436</td>
      <td>11</td>
      <td>70</td>
      <td>1</td>
      <td>plymouth satellite</td>
    </tr>
    <tr>
      <th>3</th>
      <td>16</td>
      <td>8</td>
      <td>304</td>
      <td>150</td>
      <td>3433</td>
      <td>12</td>
      <td>70</td>
      <td>1</td>
      <td>amc rebel sst</td>
    </tr>
    <tr>
      <th>4</th>
      <td>17</td>
      <td>8</td>
      <td>302</td>
      <td>140</td>
      <td>3449</td>
      <td>11</td>
      <td>70</td>
      <td>1</td>
      <td>ford torino</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>393</th>
      <td>27</td>
      <td>4</td>
      <td>140</td>
      <td>86</td>
      <td>2790</td>
      <td>16</td>
      <td>82</td>
      <td>1</td>
      <td>ford mustang gl</td>
    </tr>
    <tr>
      <th>394</th>
      <td>44</td>
      <td>4</td>
      <td>97</td>
      <td>52</td>
      <td>2130</td>
      <td>25</td>
      <td>82</td>
      <td>2</td>
      <td>vw pickup</td>
    </tr>
    <tr>
      <th>395</th>
      <td>32</td>
      <td>4</td>
      <td>135</td>
      <td>84</td>
      <td>2295</td>
      <td>12</td>
      <td>82</td>
      <td>1</td>
      <td>dodge rampage</td>
    </tr>
    <tr>
      <th>396</th>
      <td>28</td>
      <td>4</td>
      <td>120</td>
      <td>79</td>
      <td>2625</td>
      <td>19</td>
      <td>82</td>
      <td>1</td>
      <td>ford ranger</td>
    </tr>
    <tr>
      <th>397</th>
      <td>31</td>
      <td>4</td>
      <td>119</td>
      <td>82</td>
      <td>2720</td>
      <td>19</td>
      <td>82</td>
      <td>1</td>
      <td>chevy s-10</td>
    </tr>
  </tbody>
</table>
<p>398 rows × 9 columns</p>
</div>




```python
# View and call dataset to environment
x.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 398 entries, 0 to 397
    Data columns (total 9 columns):
     #   Column        Non-Null Count  Dtype 
    ---  ------        --------------  ----- 
     0   mpg           398 non-null    int64 
     1   cylinders     398 non-null    int64 
     2   displacement  398 non-null    int64 
     3   horsepower    398 non-null    object
     4   weight        398 non-null    int64 
     5   acceleration  398 non-null    int64 
     6   model_year    398 non-null    int64 
     7   origin        398 non-null    int64 
     8   name          398 non-null    object
    dtypes: int64(7), object(2)
    memory usage: 28.1+ KB
    


```python
# Find info , top 5 records , bottom 5 records
x.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>mpg</th>
      <th>cylinders</th>
      <th>displacement</th>
      <th>horsepower</th>
      <th>weight</th>
      <th>acceleration</th>
      <th>model_year</th>
      <th>origin</th>
      <th>name</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>18</td>
      <td>8</td>
      <td>307</td>
      <td>130</td>
      <td>3504</td>
      <td>12</td>
      <td>70</td>
      <td>1</td>
      <td>chevrolet chevelle malibu</td>
    </tr>
    <tr>
      <th>1</th>
      <td>15</td>
      <td>8</td>
      <td>350</td>
      <td>165</td>
      <td>3693</td>
      <td>12</td>
      <td>70</td>
      <td>1</td>
      <td>buick skylark 320</td>
    </tr>
    <tr>
      <th>2</th>
      <td>18</td>
      <td>8</td>
      <td>318</td>
      <td>150</td>
      <td>3436</td>
      <td>11</td>
      <td>70</td>
      <td>1</td>
      <td>plymouth satellite</td>
    </tr>
    <tr>
      <th>3</th>
      <td>16</td>
      <td>8</td>
      <td>304</td>
      <td>150</td>
      <td>3433</td>
      <td>12</td>
      <td>70</td>
      <td>1</td>
      <td>amc rebel sst</td>
    </tr>
    <tr>
      <th>4</th>
      <td>17</td>
      <td>8</td>
      <td>302</td>
      <td>140</td>
      <td>3449</td>
      <td>11</td>
      <td>70</td>
      <td>1</td>
      <td>ford torino</td>
    </tr>
  </tbody>
</table>
</div>




```python
x.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>mpg</th>
      <th>cylinders</th>
      <th>displacement</th>
      <th>horsepower</th>
      <th>weight</th>
      <th>acceleration</th>
      <th>model_year</th>
      <th>origin</th>
      <th>name</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>393</th>
      <td>27</td>
      <td>4</td>
      <td>140</td>
      <td>86</td>
      <td>2790</td>
      <td>16</td>
      <td>82</td>
      <td>1</td>
      <td>ford mustang gl</td>
    </tr>
    <tr>
      <th>394</th>
      <td>44</td>
      <td>4</td>
      <td>97</td>
      <td>52</td>
      <td>2130</td>
      <td>25</td>
      <td>82</td>
      <td>2</td>
      <td>vw pickup</td>
    </tr>
    <tr>
      <th>395</th>
      <td>32</td>
      <td>4</td>
      <td>135</td>
      <td>84</td>
      <td>2295</td>
      <td>12</td>
      <td>82</td>
      <td>1</td>
      <td>dodge rampage</td>
    </tr>
    <tr>
      <th>396</th>
      <td>28</td>
      <td>4</td>
      <td>120</td>
      <td>79</td>
      <td>2625</td>
      <td>19</td>
      <td>82</td>
      <td>1</td>
      <td>ford ranger</td>
    </tr>
    <tr>
      <th>397</th>
      <td>31</td>
      <td>4</td>
      <td>119</td>
      <td>82</td>
      <td>2720</td>
      <td>19</td>
      <td>82</td>
      <td>1</td>
      <td>chevy s-10</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Represent Corelation between variables
import seaborn as sns
auto=x.corr()
sns.heatmap(auto,annot=True)
```

    C:\Users\admin\AppData\Local\Temp\ipykernel_892\1394047883.py:3: FutureWarning: The default value of numeric_only in DataFrame.corr is deprecated. In a future version, it will default to False. Select only valid columns or specify the value of numeric_only to silence this warning.
      auto=x.corr()
    




    <Axes: >




    
![png](output_4_2.png)
    



```python
# plot different kinds of graphs for mean value represetation 
sns.boxplot(x='cylinders',y='weight',data=x,hue="origin")
```




    <Axes: xlabel='cylinders', ylabel='weight'>




    
![png](output_5_1.png)
    



```python
# Draw the pair plot using sns for mpg, weight,orign and with hue origin, set the size to 4
sns.pairplot(x[['mpg','weight','origin']],hue="origin",size=4)
```

    C:\Users\admin\anaconda3\Lib\site-packages\seaborn\axisgrid.py:2095: UserWarning: The `size` parameter has been renamed to `height`; please update your code.
      warnings.warn(msg, UserWarning)
    




    <seaborn.axisgrid.PairGrid at 0x2607de33a50>




    
![png](output_6_2.png)
    



```python
# identify name where acceleration is greater than 15 and horsepower less than 170
x['horsepower']=pd.to_numeric(x['horsepower'],errors='coerce')
u=x[(x['acceleration']>15)&(x['horsepower']<170)]
u
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>mpg</th>
      <th>cylinders</th>
      <th>displacement</th>
      <th>horsepower</th>
      <th>weight</th>
      <th>acceleration</th>
      <th>model_year</th>
      <th>origin</th>
      <th>name</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>15</th>
      <td>22</td>
      <td>6</td>
      <td>198</td>
      <td>95.0</td>
      <td>2833</td>
      <td>16</td>
      <td>70</td>
      <td>1</td>
      <td>plymouth duster</td>
    </tr>
    <tr>
      <th>16</th>
      <td>18</td>
      <td>6</td>
      <td>199</td>
      <td>97.0</td>
      <td>2774</td>
      <td>16</td>
      <td>70</td>
      <td>1</td>
      <td>amc hornet</td>
    </tr>
    <tr>
      <th>17</th>
      <td>21</td>
      <td>6</td>
      <td>200</td>
      <td>85.0</td>
      <td>2587</td>
      <td>16</td>
      <td>70</td>
      <td>1</td>
      <td>ford maverick</td>
    </tr>
    <tr>
      <th>19</th>
      <td>26</td>
      <td>4</td>
      <td>97</td>
      <td>46.0</td>
      <td>1835</td>
      <td>21</td>
      <td>70</td>
      <td>2</td>
      <td>volkswagen 1131 deluxe sedan</td>
    </tr>
    <tr>
      <th>20</th>
      <td>25</td>
      <td>4</td>
      <td>110</td>
      <td>87.0</td>
      <td>2672</td>
      <td>18</td>
      <td>70</td>
      <td>2</td>
      <td>peugeot 504</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>392</th>
      <td>27</td>
      <td>4</td>
      <td>151</td>
      <td>90.0</td>
      <td>2950</td>
      <td>17</td>
      <td>82</td>
      <td>1</td>
      <td>chevrolet camaro</td>
    </tr>
    <tr>
      <th>393</th>
      <td>27</td>
      <td>4</td>
      <td>140</td>
      <td>86.0</td>
      <td>2790</td>
      <td>16</td>
      <td>82</td>
      <td>1</td>
      <td>ford mustang gl</td>
    </tr>
    <tr>
      <th>394</th>
      <td>44</td>
      <td>4</td>
      <td>97</td>
      <td>52.0</td>
      <td>2130</td>
      <td>25</td>
      <td>82</td>
      <td>2</td>
      <td>vw pickup</td>
    </tr>
    <tr>
      <th>396</th>
      <td>28</td>
      <td>4</td>
      <td>120</td>
      <td>79.0</td>
      <td>2625</td>
      <td>19</td>
      <td>82</td>
      <td>1</td>
      <td>ford ranger</td>
    </tr>
    <tr>
      <th>397</th>
      <td>31</td>
      <td>4</td>
      <td>119</td>
      <td>82.0</td>
      <td>2720</td>
      <td>19</td>
      <td>82</td>
      <td>1</td>
      <td>chevy s-10</td>
    </tr>
  </tbody>
</table>
<p>199 rows × 9 columns</p>
</div>




```python
# Identify how many types of  cylinder vehicles you have
x.groupby('cylinders').sum()
```

    C:\Users\admin\AppData\Local\Temp\ipykernel_892\586912056.py:2: FutureWarning: The default value of numeric_only in DataFrameGroupBy.sum is deprecated. In a future version, numeric_only will default to False. Either specify numeric_only or select only columns which should be valid for the function.
      x.groupby('cylinders').sum()
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>mpg</th>
      <th>displacement</th>
      <th>weight</th>
      <th>acceleration</th>
      <th>model_year</th>
      <th>origin</th>
    </tr>
    <tr>
      <th>cylinders</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3</th>
      <td>83</td>
      <td>290</td>
      <td>9594</td>
      <td>55</td>
      <td>302</td>
      <td>12</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5982</td>
      <td>22399</td>
      <td>470858</td>
      <td>3413</td>
      <td>15723</td>
      <td>405</td>
    </tr>
    <tr>
      <th>5</th>
      <td>81</td>
      <td>435</td>
      <td>9310</td>
      <td>56</td>
      <td>237</td>
      <td>6</td>
    </tr>
    <tr>
      <th>6</th>
      <td>1685</td>
      <td>18324</td>
      <td>268651</td>
      <td>1378</td>
      <td>6378</td>
      <td>100</td>
    </tr>
    <tr>
      <th>8</th>
      <td>1547</td>
      <td>35536</td>
      <td>423816</td>
      <td>1349</td>
      <td>7612</td>
      <td>103</td>
    </tr>
  </tbody>
</table>
</div>




```python
# how many vehicles in every  model_year
x.groupby("model_year").count()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>mpg</th>
      <th>cylinders</th>
      <th>displacement</th>
      <th>horsepower</th>
      <th>weight</th>
      <th>acceleration</th>
      <th>origin</th>
      <th>name</th>
    </tr>
    <tr>
      <th>model_year</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>70</th>
      <td>29</td>
      <td>29</td>
      <td>29</td>
      <td>29</td>
      <td>29</td>
      <td>29</td>
      <td>29</td>
      <td>29</td>
    </tr>
    <tr>
      <th>71</th>
      <td>28</td>
      <td>28</td>
      <td>28</td>
      <td>28</td>
      <td>28</td>
      <td>28</td>
      <td>28</td>
      <td>28</td>
    </tr>
    <tr>
      <th>72</th>
      <td>28</td>
      <td>28</td>
      <td>28</td>
      <td>28</td>
      <td>28</td>
      <td>28</td>
      <td>28</td>
      <td>28</td>
    </tr>
    <tr>
      <th>73</th>
      <td>40</td>
      <td>40</td>
      <td>40</td>
      <td>40</td>
      <td>40</td>
      <td>40</td>
      <td>40</td>
      <td>40</td>
    </tr>
    <tr>
      <th>74</th>
      <td>27</td>
      <td>27</td>
      <td>27</td>
      <td>27</td>
      <td>27</td>
      <td>27</td>
      <td>27</td>
      <td>27</td>
    </tr>
    <tr>
      <th>75</th>
      <td>30</td>
      <td>30</td>
      <td>30</td>
      <td>30</td>
      <td>30</td>
      <td>30</td>
      <td>30</td>
      <td>30</td>
    </tr>
    <tr>
      <th>76</th>
      <td>34</td>
      <td>34</td>
      <td>34</td>
      <td>34</td>
      <td>34</td>
      <td>34</td>
      <td>34</td>
      <td>34</td>
    </tr>
    <tr>
      <th>77</th>
      <td>28</td>
      <td>28</td>
      <td>28</td>
      <td>28</td>
      <td>28</td>
      <td>28</td>
      <td>28</td>
      <td>28</td>
    </tr>
    <tr>
      <th>78</th>
      <td>36</td>
      <td>36</td>
      <td>36</td>
      <td>36</td>
      <td>36</td>
      <td>36</td>
      <td>36</td>
      <td>36</td>
    </tr>
    <tr>
      <th>79</th>
      <td>29</td>
      <td>29</td>
      <td>29</td>
      <td>29</td>
      <td>29</td>
      <td>29</td>
      <td>29</td>
      <td>29</td>
    </tr>
    <tr>
      <th>80</th>
      <td>29</td>
      <td>29</td>
      <td>29</td>
      <td>29</td>
      <td>29</td>
      <td>29</td>
      <td>29</td>
      <td>29</td>
    </tr>
    <tr>
      <th>81</th>
      <td>29</td>
      <td>29</td>
      <td>29</td>
      <td>29</td>
      <td>29</td>
      <td>29</td>
      <td>29</td>
      <td>29</td>
    </tr>
    <tr>
      <th>82</th>
      <td>31</td>
      <td>31</td>
      <td>31</td>
      <td>31</td>
      <td>31</td>
      <td>31</td>
      <td>31</td>
      <td>31</td>
    </tr>
  </tbody>
</table>
</div>




```python

```
